"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var PPCBaseComponents = PPCBaseComponents_1 = (function () {
    function PPCBaseComponents() {
    }
    PPCBaseComponents.prototype.PPCMessageBoxOnOk = function (e) {
        PPCBaseComponents_1.IsOpened = false;
        this.PPCMessageBoxClose(e);
    };
    PPCBaseComponents.prototype.PPCMessageBoxOnAccept = function () {
        PPCBaseComponents_1.IsOpened = false;
        this.PPCMessageBoxAccep();
    };
    PPCBaseComponents.prototype.PPCMessageBoxOnDecline = function () {
        PPCBaseComponents_1.IsOpened = false;
        this.PPCMessageBoxDecline();
    };
    PPCBaseComponents.prototype.PPCMessageBoxOnReview = function (e) {
        PPCBaseComponents_1.IsOpened = false;
        this.PPCMessageBoxReview(e);
    };
    PPCBaseComponents.PPCMessageBox = function (messageTitle, messageText, messageBoxType) {
        PPCBaseComponents_1.messageTitle = messageTitle;
        PPCBaseComponents_1.messageBoxType = messageBoxType;
        PPCBaseComponents_1.messageText = messageText;
        PPCBaseComponents_1.IsOpened = true;
    };
    Object.defineProperty(PPCBaseComponents.prototype, "staticisOpened", {
        get: function () {
            return PPCBaseComponents_1.IsOpened;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PPCBaseComponents.prototype, "staticmessageTitle", {
        get: function () {
            return PPCBaseComponents_1.messageTitle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PPCBaseComponents.prototype, "staticmessageBoxType", {
        get: function () {
            return PPCBaseComponents_1.messageBoxType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PPCBaseComponents.prototype, "staticmessageText", {
        get: function () {
            return PPCBaseComponents_1.messageText;
        },
        enumerable: true,
        configurable: true
    });
    return PPCBaseComponents;
}());
PPCBaseComponents.messageTitle = "PPC Warnings / Errors / Informations";
PPCBaseComponents.messageText = "No Message Set";
PPCBaseComponents.messageBoxType = "Ok";
PPCBaseComponents = PPCBaseComponents_1 = __decorate([
    core_1.Injectable()
], PPCBaseComponents);
exports.PPCBaseComponents = PPCBaseComponents;
var PPCBaseComponents_1;
//# sourceMappingURL=PPCBaseComponents.js.map